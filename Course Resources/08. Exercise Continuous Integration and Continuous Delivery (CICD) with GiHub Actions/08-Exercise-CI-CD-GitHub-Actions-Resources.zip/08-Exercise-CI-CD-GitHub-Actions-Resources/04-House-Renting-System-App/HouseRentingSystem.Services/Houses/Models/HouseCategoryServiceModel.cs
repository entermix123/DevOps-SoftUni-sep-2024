﻿namespace HouseRentingSystem.Services.Houses.Models
{
    public class HouseCategoryServiceModel
    {
        public int Id { get; init; }
        public string Name { get; init; }
    }
}
