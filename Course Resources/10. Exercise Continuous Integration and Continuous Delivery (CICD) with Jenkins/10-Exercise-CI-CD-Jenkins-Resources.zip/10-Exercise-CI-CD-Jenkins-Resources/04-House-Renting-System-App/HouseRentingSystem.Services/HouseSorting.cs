﻿namespace HouseRentingSystem.Services
{
    public enum HouseSorting
    {
        Newest = 0,
        Price = 1,
        NotRentedFirst = 2
    }
}



